<!-- //Scripts de neon -->
<script src="public/extras/js/tinymce/tinymce.min.js"></script>
<script src="public/extras/js/gsap/TweenMax.min.js"></script>
<script src="public/extras/js/resizeable.js"></script>
<script src="public/extras/js/neon-api.js"></script>
<script src="public/extras/js/neon-login.js"></script>
<script src="public/extras/js/jquery.validate.min.js"></script>
<script src="public/extras/js/neon-custom.js"></script>
<script src="public/extras/js/fileinput.js"></script>
