<template lang="html">
  <div class="box-step-wr step-4">
    <h2 class="h1s f-w-800 txt-blue">El material ideal para ti es:</h2>

    <div class="container material-con">
      <div class="row">
        X
      </div>
    </div>
  </div>
</template>

<script>
export default {
}
</script>
