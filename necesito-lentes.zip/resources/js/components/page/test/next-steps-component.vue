<template lang="html">
  <section class="next-steps-section">
    <div class="box-step s-2">
      <div class="container"><i class="icon"></i></div>
    </div>
    <div class="box-step s-3">
      <div class="container"><i class="icon"></i></div>
    </div>
    <div class="box-step s-4">
      <div class="container"><i class="icon"></i></div>
    </div>
    <div class="box-step s-5">
      <div class="container"><i class="icon"></i></div>
    </div>
  </section>
</template>

<script>
export default {
}
</script>
