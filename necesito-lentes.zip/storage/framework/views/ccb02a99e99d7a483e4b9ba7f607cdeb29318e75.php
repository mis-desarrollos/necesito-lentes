<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content ="<?php echo csrf_token(); ?>" />
	<link rel="icon" type="image/png"   href="public/images/favicon.png">
	<title>Necesito lentes</title>

	<link rel="stylesheet" type="text/css" href="public/css/app.css">
	
	

	
  

	<?php echo $__env->make('shared.jsDir', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
	<div id="app">
		<vue-topprogress ref="loadingBar" color="#ffffff" :height="2"></vue-topprogress>
		<my-header></my-header>
		<router-view></router-view>
		<my-footer></my-footer>
	</div>

	<script type="text/javascript" src="public/js/app.js"></script>
</body>

</html>
<?php /**PATH G:\wamp64\www\necesito-lentes\resources\views/page.blade.php ENDPATH**/ ?>