<script>
    window._proyectUrl = "<?=env('APP_URL', '/') ?>";
</script><?php /**PATH G:\wamp64\www\necesito-lentes\resources\views/shared/jsDir.blade.php ENDPATH**/ ?>